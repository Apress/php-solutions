FILES TO ACCOMPANY "PHP SOLUTIONS: DYNAMIC WEB DESIGN MADE EASY" BY DAVID POWERS (ISBN: 1590597311)
***************************************************************************************************

This zip file contains all the files necessary to work with "PHP Solutions: Dynamic Web Design Made Easy". There are four top level folders, as follows:

assets: contains two stylesheets
downloads: contains all the source code for the PHP Solutions arranged by chapter
images: the images used in the Japan Journey site
includes: this folder is EMPTY

Follow the instructions in Chapter 1 for using the files.

Every effort has been made to ensure that the files are complete, but if anything described in the book is missing, email support@friendsofed.com with brief details, mentioning the name of the book and the name(s) of the missing file(s). The author will update the source files as soon as possible.

If you think you have found an error in either the files or the book, check the book's updates and corrections page at the following addresses:

http://foundationphp.com/phpsolutions/updates.php
http://www.friendsofed.com/errata.html?isbn=1590597311

If it's not already listed there, send brief details to support@friendsofed.com outlining the problem and the page number of the book where the error occurs.