<div id="footer">
    <p>&copy; 2006 David Powers</p>
</div>
