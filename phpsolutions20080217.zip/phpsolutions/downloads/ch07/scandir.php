<?php
$files = scandir('../images');
?>
<pre>
<?php
print_r($files);
?>
</pre>