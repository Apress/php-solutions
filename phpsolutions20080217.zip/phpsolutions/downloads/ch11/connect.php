<?php
$hostname = 'localhost';
$select = 'psquery';
$admin = 'psadmin';
$selectPwd = 'fuji';
$adminPwd = 'kyoto';
?> 