<ul id="nav">
  <li><a href="index.php" id="here">Home</a></li>
  <li><a href="journal.php">Journal</a></li>
  <li><a href="gallery.php">Gallery</a></li>
  <li><a href="contact.php">Contact</a></li>
</ul>